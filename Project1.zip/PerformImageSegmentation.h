#ifndef PERFORMLMAGESEGMENTATION_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define   PERFORMLMAGESEGMENTATION_H

void PerformImageSegmentation(cv::Mat& image, cv::Mat& thresholding, int* th, int M, int L) {
	cv::Size imgSize = image.size();
	int* gray = (int*)malloc(M * sizeof(int));
	// Initialize the gray levels based on the number of bins (M) and intensity range (L).
	for (int i = 0; i < M; i++) gray[i] = i * (L / M);
	for (int y = 0; y < imgSize.height; y++)
	{
		for (int x = 0; x < imgSize.width; x++)
		{
			// Get the intensity value of the current pixel.
			int nVal = static_cast<int>(image.at<uchar>(y, x));
			// Set the initial thresholded pixel value to the maximum gray level.
			thresholding.at<uchar>(y, x) = static_cast<uchar>(gray[M - 1]);
			// Compare the intensity value with the threshold values and assign the appropriate gray level.
			for (int i = 0; i < M - 1; i++)
			{
				if (nVal <= th[i])
				{
					// Set the thresholded pixel value based on the calculated gray level.
					thresholding.at<uchar>(y, x) = static_cast<uchar>(gray[i]);
					break;
				}
			}
		}
	}
}
#endif