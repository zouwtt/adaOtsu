#ifndef OTSUEAUST_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define OTSUEAUST_H


double otsuExhaust(int M, int L, DTYPE* p, int* candidate, int* thresholds)
{
	int i;

	DTYPE* N;                   /* numerator of obejctive function length: L   */
	DTYPE* D;                   /* denominator of obejctive function length: L */

	DTYPE tempN, tempD;
	DTYPE Omax = 0.0f;
	DTYPE tempO;
	int* curthresh;             /* current tresholds                            */
	int Nt = M - 1;              /* number of tresholds                          */
	int lastep = Nt;           /* inex of last treshhold at endposition        */

#ifdef TIMING
	struct timeval tStart;      /* start time */
	struct timeval tEnd;        /* end time   */
	struct timeval tDelta;      /* time difference */
#endif

#ifdef NCALC
	nc = 0;
#endif

	/* allocate memory for the N and D array */
	if ((N = (DTYPE*)malloc(256 * sizeof(DTYPE))) == NULL) {
		printf("malloc for N array failed\n");
	}
	if ((D = (DTYPE*)malloc(256 * sizeof(DTYPE))) == NULL) {
		printf("malloc for D array failed\n");
	}

	/* allocate memory for tresholds */
	if ((curthresh = (int*)malloc(Nt * sizeof(int))) == NULL) {
		printf("malloc for treshold array failed\n");
	}

#ifdef TIMING
	/* start timing here */
	gettimeofday(&tStart, NULL);
#endif

	/* initialize N and D array*/
	N[0] = 0;
	D[0] = p[0];
	for (i = 1; i < 256; i++) {
		N[i] = N[i - 1] + i * p[i];
		D[i] = D[i - 1] + p[i];
	}

	/* initialize tresholds to start posistion                     */
	for (i = 0; i < Nt; i++) {
		curthresh[i] = i;
	}

	/* perform an exhaustive search over all possible combinations */
	do {
	end_loop:
		/* if an overflow has occured, move the affected trsh. back */
		for (i = 1; i < Nt - lastep; i++) {
			curthresh[lastep + i] = curthresh[lastep + i - 1] + 1;
		}
		lastep = Nt;

#ifdef NCALC
		nc += (uint64_t)M;
#endif 
		// Calculate objective function using candidate array
		// First class 0..1st threshold
	//	printf("%d", candidate[curthresh[0]]);
		tempN = N[candidate[curthresh[0]]];
		tempD = D[candidate[curthresh[0]]];
		tempO = (tempD != 0) ? (tempN * tempN / tempD) : 0;
		//tempD*(tempN/tempD-N[255])*(tempN/tempD-N[255])
		//tempN * tempN / tempD
		//((N[255]*tempD-tempN)*(N[255]*tempD-tempN))/(tempD*(1-tempD))
		/* middle classes */
		for (i = 0; i < Nt - 1; i++) {
			tempD = D[candidate[curthresh[i + 1]]] - D[candidate[curthresh[i]]];
			if (tempD != 0.0) {
				tempN = N[candidate[curthresh[i + 1]]] - N[candidate[curthresh[i]]];
				tempO = tempO + tempN * tempN / tempD;
			}
		}
		/* last class lasttreshold+1....L-1 */
		tempD = D[candidate[L - 1]] - D[candidate[curthresh[Nt - 1]]];
		if (tempD != 0.0) {
			tempN = N[candidate[L - 1]] - N[candidate[curthresh[Nt - 1]]];
			tempO = tempO + tempN * tempN / tempD;
		}

		if (tempO > Omax) {
			Omax = tempO;
			for (i = 0; i < Nt; i++) {
				thresholds[i] = candidate[curthresh[i]];
			}
		}

		for (i = Nt - 1; i >= 0; i--) {
			if (curthresh[i] != L - Nt - 1 + i) {
				curthresh[i]++;
				/* go back to end_loop   */
				goto end_loop;
			}
			else {
				/* treshold is at it's endposition, move treshold back to the correct pos */
				/* the for loop continues, which means that treshold i-1 is increased     */
				/* when more then one treshold is at endpos, the treshold positions need  */
				/* to be corrected, for this lastep is needed.                            */
				if (i != 0) {
					curthresh[i] = curthresh[i - 1] + 2;
				}
				lastep = i;
			}
		}

	} while (curthresh[0] != L - Nt - 1);

#ifdef TIMING
	/* end timing, calculate time difference */
	gettimeofday(&tEnd, NULL);
	timevalSubtract(&tDelta, &tEnd, &tStart);
#ifdef NCALC
	printf("%f\t", (double)(tDelta.tv_sec) + 1.0E-6 * (double)(tDelta.tv_usec));
#else
	printf("%f\n", (double)(tDelta.tv_sec) + 1.0E-6 * (double)(tDelta.tv_usec));
#endif
#endif

#ifdef NCALC
	printf("%u\n", nc);
#endif
	DTYPE s = 0.0f;
	for (int j = 0; j < Nt; j++) {
		s += p[thresholds[j]];
	}
	Omax = (1.0 - s) * Omax;
	free(N);
	free(D);
	return Omax;
}
 
#endif
