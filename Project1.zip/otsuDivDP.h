#ifndef OTSUDIVDP_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define OTSUDIVDP_H

void matrixSearch(int lCornerY, int lCornerX, int rCornerY, int rCornerX, int* candidate);
double otsuDivDP(int M, int L, DTYPE* p, int* candidate, int* thresholds)
{
	int i, j, c;
	int Q = L - M + 1;          /* nodes per class */

	struct NODE* searchNODE;    /* used for the backtracking */
	int* index;
	DTYPE Omax = 0;
	int   Omaxpos = 0;

#ifdef TIMING
	struct timeval tStart;      /* start time */
	struct timeval tEnd;        /* end time   */
	struct timeval tDelta;      /* time difference */
#endif

#ifdef NCALC
	nc = 0;
#endif


	/* allocate memory for the trellis structure */
	if ((trellis = (NODE**)malloc(M * sizeof(struct NODE*))) == NULL) {
		printf("malloc for trellis M-dim falied\n");
	}
	for (i = 0; i < M; i++) {
		if ((trellis[i] = (NODE*)malloc(L * sizeof(struct NODE))) == NULL) {
			printf("malloc for trellis L-dim failed\n");
		}
		memset(trellis[i], 0, L * sizeof(struct NODE));
	}

	/* allocate memory for the N and D array */
	if ((N = (DTYPE*)malloc(256 * sizeof(DTYPE))) == NULL) {
		printf("malloc for N array failed\n");
	}
	if ((D = (DTYPE*)malloc(256 * sizeof(DTYPE))) == NULL) {
		printf("malloc for D array failed\n");
	}
	if ((index = (int*)malloc(M * sizeof(int))) == NULL) {
		printf("malloc for index array failed\n");
	}

#ifdef TIMING
	/* start timing here */
	gettimeofday(&tStart, NULL);
#endif

	/* initialize N and D array*/
	N[0] = 0;
	D[0] = p[0];
	for (i = 1; i < 256; i++) {
		N[i] = N[i - 1] + i * p[i];
		D[i] = D[i - 1] + p[i];
	}
	/* initialize the trellis structure for the lowest level (class = 0) */
	if (D[candidate[0]] == 0)            /* to avoid division by zero */
		trellis[0][0].O = 0;
	else
		trellis[0][0].O = N[candidate[0]] * N[candidate[0]] / D[candidate[0]];
	for (i = 1; i < Q; i++) {
		if (D[candidate[i]] == 0)
			trellis[0][i].O = trellis[0][i - 1].O;
		else
			trellis[0][i].O = N[candidate[i]] * N[candidate[i]] / D[candidate[i]];
	}

	/* begin shortest (here longest) path algorithm */
	for (c = 1; c < (M - 1); c++) {
		stage = c;
		matrixSearch(c, c - 1, c + Q - 1, c + Q - 2, candidate);
	}

	c = M - 1; i = L - 1; Omax = 0;       /* last class is spezial treated */
	for (j = M - 2; j < (L - 1); j++) {
		//Ntemp = N[i] - N[j];
		//Dtemp = D[i] - D[j];
		Ntemp = N[candidate[i]] - N[candidate[j]];
		Dtemp = D[candidate[i]] - D[candidate[j]];
		if (Dtemp == 0)
			Otemp = trellis[c - 1][j].O;
		else
			Otemp = trellis[c - 1][j].O + Ntemp * Ntemp / Dtemp;
		if (Otemp > Omax) {
			Omax = Otemp;
			Omaxpos = j;
		}
	}
	trellis[c][i].O = Omax;
	trellis[c][i].p_back = &trellis[c - 1][Omaxpos];

	/* backtrack */
	searchNODE = &(trellis[M - 1][L - 1]);
	for (i = M - 1; i > 0; i--) {
		searchNODE = searchNODE->p_back;
		index[i - 1] = (searchNODE - trellis[i - 1]);
	}
	for (i = M - 1; i > 0; i--) {

		thresholds[i - 1] = candidate[index[i - 1]];
	}
#ifdef TIMING
	/* end timing, calculate time difference */
	gettimeofday(&tEnd, NULL);
	timevalSubtract(&tDelta, &tEnd, &tStart);
#ifdef NCALC
	printf("%f\t", (double)(tDelta.tv_sec) + 1.0E-6 * (double)(tDelta.tv_usec));
#else
	printf("%f\n", (double)(tDelta.tv_sec) + 1.0E-6 * (double)(tDelta.tv_usec));
#endif
#endif

#ifdef NCALC
	nc += 2 * (L - M + 1);
	printf("%u\n", nc);
#endif
	DTYPE s = 0.0f;
	for (int j = 0; j < M - 1; j++) {
		s += p[thresholds[j]];
	}
	Omax = (1.0 - s) * Omax;
	for (i = 0; i < M; i++) {
		free(trellis[i]);
	}
	free(trellis);
	free(N);
	free(D);

	return Omax;
}
void matrixSearch(int lCornerY, int lCornerX, int rCornerY, int rCornerX, int* candidate)
{
	int i, j;
	DTYPE Omax;
	int Omaxpos = 0;

	i = (lCornerY + rCornerY) / 2;      /* divide matrix */

	/* find maximum in row i */
	Omax = 0;
	for (j = lCornerX; (j <= rCornerX) && (j < i); j++) {
#ifdef NCALC
		nc++;
#endif
		//Ntemp = N[i] - N[j];
		//Dtemp = D[i] - D[j];
		Ntemp = N[candidate[i]] - N[candidate[j]];
		Dtemp = D[candidate[i]] - D[candidate[j]];
		if (Dtemp == 0)
			Otemp = trellis[stage - 1][j].O;
		else
			Otemp = trellis[stage - 1][j].O + Ntemp * Ntemp / Dtemp;
		if (Otemp > Omax) {
			Omax = Otemp;
			Omaxpos = j;
		}
	}
	trellis[stage][i].O = Omax;
	trellis[stage][i].p_back = &trellis[stage - 1][Omaxpos];

	/* search resulting matrices recursively */
	if (i - lCornerY > 0)
		matrixSearch(lCornerY, lCornerX, i - 1, Omaxpos, candidate);
	if (rCornerY - i > 0)
		matrixSearch(i + 1, Omaxpos, rCornerY, rCornerX, candidate);
	return;
}

#endif