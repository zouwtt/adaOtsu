#ifndef REGION_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define REGION_H
bool IsRedPixel(cv::Vec3b pixel);
cv::Mat region(vector<int>& vecLabel, cv::Mat& thresholding, const CvSize& imgSize, int nMinRegion) {
	for (int i = 0, y = 0; y < imgSize.height; y++) {
		for (int x = 0; x < imgSize.width; x++, i++) {
			int Val = static_cast<int>(thresholding.at<uchar>(y, x));
			vecLabel[i] = Val;
			//printf("%d ", vecLabel[i]);
		}
	}
	// ����һ����ά�������洢ͼ������
	vector<vector<int>> vecImgData(3, vector<int>(imgSize.width * imgSize.height));
	// ����ͼ���ÿ�����أ������Ҷ�ֵ�洢�� vecImgData ��
	for (int y = 0; y < imgSize.height; y++) {
		for (int x = 0; x < imgSize.width; x++) {
			int pixel = static_cast<int>(thresholding.at<uchar>(y, x));
			vecImgData[0][y + x] = pixel;
			//printf("%d ", vecImgData[0][y+x]);

		}
	}
	int nRegionNum = ExtractConnectedRegion(vecLabel, vecImgData, imgSize, nMinRegion);
	//printf("%d\n ", nRegionNum);
	cv::Mat regionImage(thresholding.size(), CV_8UC1);
	for (int i = 0, y = 0; y < imgSize.height; y++)
	{
		for (int x = 0; x < imgSize.width; x++, i++)
		{
			//printf("%d ", vecLabel[i]);
			regionImage.at<uchar>(y, x) = static_cast<uchar>(vecLabel[i]);
		}
	}
	cv::Mat pRegionImage = cv::Mat::zeros(thresholding.size(), CV_8UC3);
	cvtColor(regionImage, pRegionImage, cv::COLOR_GRAY2BGR); // ���Ҷ�ͼ��ת��Ϊ BGR ��ʽ
	// ���� ExtractContour ������ȡ��Ե
	ExtractContour(regionImage, pRegionImage, cv::Scalar(0, 0, 255));
	return pRegionImage;
}
 
bool IsRedPixel(cv::Vec3b pixel) {
	int red = pixel[2];  // Red channel (R) value
	int green = pixel[1];  // Green channel (G) value


	int blue = pixel[0];  // Blue channel (B) value

	// Define a threshold for redness, you can adjust this threshold
	int redThreshold = 255;

	// Check if the red component is significantly higher than green and blue
	return (red == redThreshold && green == 0 && blue == 0);
}
#endif
