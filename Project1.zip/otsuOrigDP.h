#ifndef OTSUORIGDP_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define OTSUORIGDP_H
double otsuOrigDP(int M, int L, DTYPE* p, int* candidate, int* thresholds)
{
	int i, j, r;
	int Q = L - M + 1;          /* nodes per class */

	//struct NODE** trellis;      /* trellis structure MxL */
	struct NODE* searchNODE;    /* used for the backtracking */
	DTYPE* N;                   /* numerator of objective function length: L */
	DTYPE* D;                   /* denominator of objective function length: L */

	int* index;
	//DTYPE Otemp, Ntemp, Dtemp;
	DTYPE Omax = 0;
	int   Omaxpos = 0;

#ifdef TIMING
	struct timeval tStart;      /* start time */
	struct timeval tEnd;        /* end time   */
	struct timeval tDelta;      /* time difference */
#endif

#ifdef NCALC
	nc = 0;
#endif

	/* allocate memory for the trellis structure */
	if ((trellis = (NODE**)malloc(M * sizeof(struct NODE*))) == NULL) {
		printf("malloc for trellis M-dim falied\n");
	}
	for (i = 0; i < M; i++) {
		if ((trellis[i] = (NODE*)malloc(L * sizeof(struct NODE))) == NULL) {
			printf("malloc for trellis L-dim failed\n");
		}
		memset(trellis[i], 0, L * sizeof(struct NODE));
	}

	/* allocate memory for the N and D array */
	if ((N = (DTYPE*)malloc(256 * sizeof(DTYPE))) == NULL) {
		printf("malloc for N array failed\n");
	}
	if ((D = (DTYPE*)malloc(256 * sizeof(DTYPE))) == NULL) {
		printf("malloc for D array failed\n");
	}
	if ((index = (int*)malloc(M * sizeof(int))) == NULL) {
		printf("malloc for index array failed\n");
	}

#ifdef TIMING
	/* start timing here */
	gettimeofday(&tStart, NULL);
#endif

	/* initialize N and D array*/
	N[0] = 0;
	D[0] = p[0];
	for (i = 1; i < 256; i++) {
		N[i] = N[i - 1] + i * p[i];
		D[i] = D[i - 1] + p[i];
	}

	/* initialize the trellis structure for the lowest level (class = 0) */
	if (D[candidate[0]] == 0)            /* to avoid division by zero */
		trellis[0][0].O = 0;
	else
		trellis[0][0].O = N[candidate[0]] * N[candidate[0]] / D[candidate[0]];
	for (i = 1; i < Q; i++) {
		if (D[candidate[i]] == 0)
			trellis[0][i].O = trellis[0][i - 1].O;
		else
			trellis[0][i].O = N[candidate[i]] * N[candidate[i]] / D[candidate[i]];
	}

	/* begin shortest (here longest) path algorithm */
	for (i = 1; i < (M - 1); i++) {
		for (j = i; j < (Q + i); j++) {
			Omax = 0;
			for (r = i - 1; r < j; r++) {
				Ntemp = N[candidate[j]] - N[candidate[r]];
				Dtemp = D[candidate[j]] - D[candidate[r]];
				if (Dtemp == 0)
					Otemp = trellis[i - 1][r].O;
				else
					Otemp = trellis[i - 1][r].O + Ntemp * Ntemp / Dtemp;
				if (Otemp > Omax) {
					Omax = Otemp;
					Omaxpos = r;
				}
			}
			trellis[i][j].O = Omax;
			trellis[i][j].p_back = &trellis[i - 1][Omaxpos];
		}
	}
	i = M - 1; j = L - 1; Omax = 0;       /* last class is spezial treated */
	for (r = M - 2; r < (L - 1); r++) {
		Ntemp = N[candidate[j]] - N[candidate[r]];
		Dtemp = D[candidate[j]] - D[candidate[r]];
		if (Dtemp == 0)
			Otemp = trellis[i - 1][r].O;
		else
			Otemp = trellis[i - 1][r].O + Ntemp * Ntemp / Dtemp;
		if (Otemp > Omax) {
			Omax = Otemp;
			Omaxpos = r;
		}
	}
	trellis[i][j].O = Omax;
	trellis[i][j].p_back = &trellis[i - 1][Omaxpos];


	/* backtrack */
	searchNODE = &(trellis[M - 1][L - 1]);
	for (i = M - 1; i > 0; i--) {
		searchNODE = searchNODE->p_back;
		index[i - 1] = (searchNODE - trellis[i - 1]);
	}
	for (i = M - 1; i > 0; i--) {

		thresholds[i - 1] = candidate[index[i - 1]];
	}


#ifdef TIMING
	/* end timing, calculate time difference */
	gettimeofday(&tEnd, NULL);
	timevalSubtract(&tDelta, &tEnd, &tStart);
#ifdef NCALC
	printf("%f\t", (double)(tDelta.tv_sec) + 1.0E-6 * (double)(tDelta.tv_usec));
#else
	printf("%f\n", (double)(tDelta.tv_sec) + 1.0E-6 * (double)(tDelta.tv_usec));
#endif
#endif

#ifdef NCALC
	nc = 2 * ((uint64_t)L - (uint64_t)M + 1) +
		((uint64_t)M - 2) * ((uint64_t)L - (uint64_t)M + 1) * ((uint64_t)L - (uint64_t)M + 2) / 2;
	printf("%u\n", nc);
#endif

	DTYPE s = 0.0f;
	for (int j = 0; j < M - 1; j++) {
		s += p[thresholds[j]];
	}
	Omax = (1.0 - s) * Omax;
	for (i = 0; i < M; i++) {
		free(trellis[i]);
	}
	free(trellis);
	free(N);
	free(D);

	return Omax;
}
#endif