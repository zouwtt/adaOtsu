#ifndef ORDER_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define ORDER_H
void order(cv::Mat& image, int* candidate, int *newL, double* p) {
	int i;
	int L = 256;
	cv::Size imgSize = image.size();
	//ShowHistogram(image, 0, 0, 0);
	for (int y = 0; y < imgSize.height; y++)
	{
		for (int x = 0; x < imgSize.width; x++)
		{
			int nVal = static_cast<int>(image.at<uchar>(y, x)); // ��ȡ�Ҷ�ֵ
			p[nVal]++;
		}
	}
	int total = imgSize.width * imgSize.height;
	for (int i = 0; i < L; i++) p[i] /= total;
	derivative* fistorder;
	if ((fistorder = (derivative*)malloc(L - 1 * sizeof(derivative))) == NULL) {
		printf("malloc for pixel differences array failed\n");
	}
	derivative* secondorder;
	if ((secondorder = (derivative*)malloc(L - 2 * sizeof(derivative))) == NULL) {
		printf("malloc for pixel differences array failed\n");
	}
	// Calculate pixel differences (left and right neighbors)
	for (i = 0; i < L - 1; i++) {
		fistorder[i].der = p[i + 1] - p[i];
		fistorder[i].p = i;
	}
	for (i = 0; i < L - 2; i++) {
		secondorder[i].der = fistorder[i + 1].der - fistorder[i].der;
		secondorder[i].p = i;
	}
	int j = 0;
	for (i = 0; i < L - 2; i++) {
			if (secondorder[i].der > 0) {
				candidate[j] = fistorder[i].p;
				j++;
			}
	}
	for (int i = 0; i < j; i++)
	{
		printf("%d\n ", candidate[i]);
	}
	*newL = j;
	free(fistorder);
	free(secondorder);
	return;
}
#endif