#ifndef SAVEBESTTHRESHOLDS_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define SAVEBESTTHRESHOLDS_H
void saveBestThresholds(const string& outputPath, const string& imageName, int* bestTH, int bestM) {
	ofstream outputFile(outputPath, ios::app);
	if (!outputFile.is_open()) {
		cerr << "Error: Could not open the output file" << endl;
		return;
	}
	for (int i = 0; i < bestM - 1; i++) {
		outputFile << bestTH[i] << " ";
	}
	outputFile << "\n";

	outputFile.close();
}
#endif
