#ifndef EXTRACTCONTOUR_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define EXTRACTCONTOUR_H

bool ExtractContour(cv::Mat& pDstImage, cv::Mat& pContourImage, cv::Scalar color)
{
	if (pDstImage.empty()) return false;
	if (pContourImage.empty() || pContourImage.channels() != 3) return false;

	cv::Size imgSize = pDstImage.size();
	int nStep = pDstImage.step1();
	uchar* pPreData = pDstImage.ptr<uchar>();
	uchar* pDstData = pDstImage.ptr<uchar>() + nStep;
	uchar* pNextData = pDstImage.ptr<uchar>() + 2 * nStep;

	cv::Mat pBndyImage = cv::Mat::ones(imgSize, CV_8U) * 255; // ������Եͼ��

	imgSize.width -= 1;
	imgSize.height -= 1;
	for (int y = 1; y < imgSize.height; y++)
	{
		for (int x = 1; x < imgSize.width; x++)
		{
			int nXGrad = abs(pDstData[x + 1] - pDstData[x - 1]);
			int nYGrad = abs(pNextData[x] - pPreData[x]);
			int nGrad = nXGrad + nYGrad;
			if (nGrad > 0) {
				pContourImage.at<cv::Vec3b>(y, x) = cv::Vec3b(color[0], color[1], color[2]);
				pBndyImage.at<uchar>(y, x) = 0;
			}
		}
		pPreData += nStep;
		pDstData += nStep;
		pNextData += nStep;
	}

	//cv::imwrite("boundary.tiff", pBndyImage); // �����Եͼ��

	return true;
}
#endif

