#ifndef UM_H //����ͷ�ļ�����ȫ��д��Ӹ�_H

#define UM_H

double* UM(cv::Mat& I, int* T, int length) {
    int c = length + 1;
    double fmax = 0.0, fmin = 0.0;

    // Find fmax and fmin
    for (int i = 0; i < I.rows; i++) {
        for (int j = 0; j < I.cols; j++) {
            double current = (double)I.at<uchar>(i, j);
            if (current > fmax) {
                fmax = current;
            }
            if (current < fmin) {
                fmin = current;
            }
        }
    }

    // Allocate memory for histogram
    int* h = (int*)malloc((length + 1) * sizeof(int));
    if (h == NULL) {
        std::cerr << "Memory allocation failed" << std::endl;
        exit(1);
    }

    // Initialize histogram
    for (int i = 0; i <= length; i++) {
        h[i] = 0;
    }

    // Populate histogram
    for (int i = 0; i < I.rows; i++) {
        for (int j = 0; j < I.cols; j++) {
            h[I.at<uchar>(i, j)]++;
        }
    }

    // Calculate N, s
    int N = 0, s = length + 1;
    for (int i = 0; i <= length; i++) {
        N += h[i];
    }
    // Allocate memory for S
    double* S = (double*)malloc(c * sizeof(double));
    if (S == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    // Calculate S(j)
    S[0] = h[0];
    S[c - 1] = h[length];
    for (int i = 1; i < c - 1; i++) {
        S[i] = h[T[i - 1] + 1];
    }

    // Allocate memory for miu
    double* miu = (double*)malloc(c * sizeof(double));
    if (miu == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    // Calculate miu(j)
    double* num = (double*)malloc((length + 1) * sizeof(double));
    if (num == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    for (int i = 0; i <= length; i++) {
        num[i] = (double)h[i] * i;
    }

    miu[0] = num[T[0]] / S[0];
    miu[c - 1] = num[length] / S[c - 1];
    for (int i = 1; i < c - 1; i++) {
        miu[i] = num[T[i - 1] + 1] / S[i];
    }

    // Allocate memory for Fi
    double* Fi = (double*)malloc(c * sizeof(double));
    if (Fi == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    // Calculate Fi(j)
    Fi[0] = 0.0;
    Fi[c - 1] = 0.0;
    for (int i = 1; i < c - 1; i++) {
        Fi[i] = 0.0;
    }

    for (int i = 0; i < T[0]; i++) {
        Fi[0] += (i - miu[0]) * (i - miu[0]) * h[i];
    }

    for (int i = T[c - 2] + 1; i <= length; i++) {
        Fi[c - 1] += (i - miu[c - 1]) * (i - miu[c - 1]) * h[i];
    }

    for (int j = 1; j < c - 1; j++) {
        for (int i = T[j - 1] + 1; i <= T[j]; i++) {
            Fi[j] += (i - miu[j]) * (i - miu[j]) * h[i];
        }
    }

    // Calculate u
    double sumFi = 0.0;
    for (int i = 0; i < c; i++) {
        sumFi += Fi[i];
    }
    double u = sumFi / (N * (fmax - fmin) * (fmax - fmin));
    // Calculate U
    double U = 1 - 2 * (c - 1) * u;
    // Free allocated memory
    free(h);
    free(S);
    free(miu);
    free(num);
    free(Fi);

    // Return result
    double* result = (double*)malloc(sizeof(double));
    result[0] = U;
    return result;
}

#endif
